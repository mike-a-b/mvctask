<?php
namespace App\Controller;

class User
{
    function indexAction()
    {
        echo __METHOD__;
        echo "indexAction";
    }
}