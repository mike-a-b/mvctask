<?php
namespace App\Controller\Auth;

Class Login {
    public function indexAction() {
        echo __METHOD__;
    }
}

